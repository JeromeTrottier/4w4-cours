# 4w4 - Conception d'interface et développement Web
### Auteur : Eddy Martin
### Semaine #5 cours #2: Engin de recherche de wp

Développement des modules:
 - search.php
 - searchform.php
Développement d'un nouveau mixin link_menu

 Début d'une animation

Pour modifier readme.md
https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax
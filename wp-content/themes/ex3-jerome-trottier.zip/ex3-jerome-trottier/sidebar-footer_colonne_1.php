<div id="sidebar-footer_colonne_1" class="sidebar">
    <?php dynamic_sidebar( 'footer_colonne_1' ); ?>
</div>
<footer class="footer">
    <h2 class="footer__titre">Un magnifique footer</h2>
    <p class="footer__presentation">Un site web fait à l'aide de wordpress en TIM</p>
    <h3 class="footer__author">Fait par Jérôme Trottier</h3>
</footer>
</body>

</html>
<div id="sidebar-entete_1" class="sidebar">
    <?php dynamic_sidebar( 'entete_1' ); ?>
</div>
# Lab4 - 4W4 - Conception d'interface et développement Web

### Auteur Jérôme Trottier

### Date de remise : 11 février 2022

```
Cet exercice nous a permis d'introduire la structure d'un thème Wordpress. Voici la structure utilisée :
-Pour le style css, nous avons utilisé un Sass
-Les fonctions de thème se trouvent dans 'functions.php'
-Les modèles principal est : 'index.php'
```
